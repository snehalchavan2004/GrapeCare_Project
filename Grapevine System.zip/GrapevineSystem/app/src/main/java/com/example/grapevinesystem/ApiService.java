package com.example.grapevinesystem;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface ApiService {
    @Headers("Authorization: Bearer YOUR_OPENAI_API_KEY")
    @POST("https://api.openai.com/v1/chat/completions")
    Call<ChatResponse> getBotReply(@Body ChatRequest request);
}
