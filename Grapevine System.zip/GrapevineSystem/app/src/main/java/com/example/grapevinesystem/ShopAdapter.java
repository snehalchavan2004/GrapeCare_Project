package com.example.grapevinesystem;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ShopAdapter extends RecyclerView.Adapter<ShopAdapter.ViewHolder> {
    private Context context;
    private List<AgriShop> shopList;

    public ShopAdapter(Context context, List<AgriShop> shopList) {
        this.context = context;
        this.shopList = shopList;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView shopName;
        ImageView shopImage;

        public ViewHolder(View itemView) {
            super(itemView);
            shopName = itemView.findViewById(R.id.shopName);
            shopImage = itemView.findViewById(R.id.shopImage);
        }
    }

    @Override
    public ShopAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.activity_item_shop, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ShopAdapter.ViewHolder holder, int position) {
        AgriShop shop = shopList.get(position);
        holder.shopName.setText(shop.name);
    }
    public void updateShops(List<AgriShop> newShops) {
        this.shopList.clear();
        this.shopList.addAll(newShops);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return shopList.size();
    }
}
