package com.example.grapevinesystem;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class LoginActivity extends AppCompatActivity {

    EditText loginusername, loginpassword;
    Button loginbutton;
    TextView signupdirectText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        loginusername = findViewById(R.id.login_username);
        loginpassword = findViewById(R.id.login_password);
        loginbutton = findViewById(R.id.Login_button);
        signupdirectText = findViewById(R.id.loginRedirectText);
        ImageView lefticon=findViewById(R.id.lefticon);
        TextView textView=findViewById(R.id.texttitle);
        lefticon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(intent);
            }

        });
        textView.setText("Join AgriXpert");
        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("LoginButtonClick", "Login button clicked");

                // Add a Toast to visually indicate the button click
                Toast.makeText(LoginActivity.this, "Login button clicked", Toast.LENGTH_SHORT).show();

                if (!validateusername() | !validatepassword()) {
                    Log.d("LoginValidation", "Validation failed");
                } else {
                    Log.d("LoginValidation", "Validation passed, checking user");
                    checkuser();
                }
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
                finish();

            }
        });
        signupdirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(intent);
            }
        });

    }

    public Boolean validateusername() {
        String val = loginusername.getText().toString();
        if (val.isEmpty()) {
            loginusername.setError("Username cannot be empty");
        } else {
            loginusername.setError(null);
            return true;
        }
        return true;
    }

    public Boolean validatepassword() {
        String val = loginpassword.getText().toString();
        if (val.isEmpty()) {
            loginpassword.setError("Username cannot be empty");
        } else {
            loginpassword.setError(null);
            return true;
        }
        return true;
    }

    public void checkuser() {
        String userusername = loginusername.getText().toString().trim();
        String password = loginpassword.getText().toString().trim();
        Log.d("LoginAttempt", "Attempting to login with username: " + userusername + " and password: " + password);
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("users"); // Reference to the "users" node
        Query checkuserDatabase = reference.orderByChild("username").equalTo(userusername);

        checkuserDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Log.d("FirebaseSnapshot", "User exists, checking password");

                    String passwordfromDB = null;
                    for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                        passwordfromDB = userSnapshot.child("password").getValue(String.class);
                        break;
                    }

                    if (passwordfromDB != null && passwordfromDB.equals(password)) {
                        Log.d("LoginSuccess", "Password matched");
                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Log.d("LoginError", "Password mismatch");
                        loginpassword.setError("Invalid Credentials");
                        loginpassword.requestFocus();
                    }
                } else {
                    Log.d("LoginError", "User does not exist");
                    loginusername.setError("User does not exist");
                    loginusername.requestFocus();
                }

            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle database errors (if any)
                Toast.makeText(LoginActivity.this, "Database error occurred", Toast.LENGTH_SHORT).show();
            }
        });


    }
}

