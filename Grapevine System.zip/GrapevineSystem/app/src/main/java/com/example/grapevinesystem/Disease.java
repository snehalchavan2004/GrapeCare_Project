package com.example.grapevinesystem;

public class Disease {
    private String disease;
    private String symptoms;
    private String precautions;
    private String remedies;

    public String getDisease() {
        return disease;
    }

    public String getSymptoms() {
        return symptoms;
    }

    public String getPrecautions() {
        return precautions;
    }

    public String getRemedies() {
        return remedies;
    }
}
