package com.example.grapevinesystem;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.PopupMenu;
import android.widget.Toast;
import com.example.grapevinesystem.R;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class MainActivity extends AppCompatActivity {

    private ImageView lefticon;
    private TextView textView;
    private ImageButton dehazeicon;
    private  BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views AFTER setContentView
        lefticon = findViewById(R.id.lefticon);
        textView = findViewById(R.id.texttitle);
       bottomNavigationView= findViewById(R.id.bottom_navigation);

       showbottomMenu();
        // Optional: WindowInsets handling (ensure R.id.main exists in your layout)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Button for capturing an image
        Button capturebtn = findViewById(R.id.capturebutton);
        capturebtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, capture_image_activity.class);
            startActivity(intent);
        });
        dehazeicon = findViewById(R.id.dehaze_icon);

        dehazeicon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("MainActivity", "Dehaze Icon Clicked!");
                showDropdownMenu(v);
            }
        });


        Button uploadbtn2 = findViewById(R.id.uploadbutton);
        uploadbtn2.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, upload_image_activity.class);
            startActivity(intent);
        });
        FloatingActionButton fabChatbot = findViewById(R.id.fabChatbot);

        fabChatbot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ChatbotActivity.class);
                startActivity(intent);
            }
        });

        // Handle left icon click
        lefticon.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, SignUpActivity.class);
            startActivity(intent);
        });

        // Set text for the TextView
        textView.setText("AgriXpert");


    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_home) {
            // Open the new Feedback activity
            Intent intent = new Intent(MainActivity.this, feedback.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }




    private void showDropdownMenu(View v) {
        PopupMenu popupMenu = new PopupMenu(MainActivity.this, v);
        popupMenu.getMenuInflater().inflate(R.menu.dehaze_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.menu_home) {
                Intent intent = new Intent(MainActivity.this,feedback.class);
                startActivity(intent);
            } else if (itemId == R.id.menu_settings) {
                Intent intent = new Intent(MainActivity.this,SignUpActivity.class);
                startActivity(intent);
            } else if (itemId == R.id.menu_thanks) {
                Intent intent = new Intent(MainActivity.this, thank_you.class);
                startActivity(intent);
            }
            return false;
        });

        popupMenu.show();
    }

    private void showbottomMenu() {
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.navigation_home) {
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                startActivity(intent);
                return true;

            } else if (itemId == R.id.navigation_profile) {
                Intent intent = new Intent(MainActivity.this, profile.class);
                startActivity(intent);
                return true;

            } else if (itemId == R.id.navigation_shop) {
                Log.d("BottomNav", "Shop selected");
                Intent intent = new Intent(MainActivity.this, agrishopActivity.class);
                startActivity(intent);
                return true;
            }

            return false;
        });
    }

}

