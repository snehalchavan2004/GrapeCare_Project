package com.example.grapevinesystem;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.tensorflow.lite.Interpreter;

import java.io.FileInputStream;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.io.IOException;

public class capture_image_activity extends AppCompatActivity {

    private static final int CAMERA_REQUEST_CODE = 100;
    private static final int IMAGE_SIZE = 128;  // Updated to match model
    private static final int FLOAT_SIZE = 4;
    private static final int NUM_CLASSES = 4;

    private ImageView imgCaptured, lefticon;
    private TextView textView;
    private Interpreter tflite;
    private ImageButton dehazeicon;
    private Bitmap capturedBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_capture_image);

        lefticon = findViewById(R.id.lefticon);
        textView = findViewById(R.id.texttitle);
        imgCaptured = findViewById(R.id.imgCaptured);
        Button btnOpenCamera = findViewById(R.id.btnCaptureImage);
        Button btnDetectDisease = findViewById(R.id.btnDetect);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST_CODE);
        }

        // Load TFLite Model
        try {
            tflite = new Interpreter(loadModelFile());
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading model!", Toast.LENGTH_SHORT).show();
        }

        // Open Camera on Button Click
        btnOpenCamera.setOnClickListener(v -> {
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE);
        });

        // Left icon back button
        lefticon.setOnClickListener(view -> {
            Intent intent = new Intent(capture_image_activity.this, MainActivity.class);
            startActivity(intent);
        });

        // Set App Title
        textView.setText("AgriXpert");

        // Detect Disease on Button Click
        btnDetectDisease.setOnClickListener(v -> {
            if (capturedBitmap != null) {
                String detectedDisease = classifyImage(capturedBitmap);
                Intent intent = new Intent(capture_image_activity.this, result.class);
                intent.putExtra("disease_name", detectedDisease);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Please capture an image first!", Toast.LENGTH_SHORT).show();
            }
        });
        dehazeicon = findViewById(R.id.dehaze_icon);

        dehazeicon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("MainActivity", "Dehaze Icon Clicked!");
                showDropdownMenu(v);
            }
        });
    }

    // Handle Camera Result
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            if (photo != null) {
                capturedBitmap = Bitmap.createScaledBitmap(photo, IMAGE_SIZE, IMAGE_SIZE, true);
                imgCaptured.setImageBitmap(capturedBitmap);
            } else {
                Toast.makeText(this, "Failed to capture image!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Load the TFLite model from assets folder
    private MappedByteBuffer loadModelFile() throws IOException {
        AssetFileDescriptor fileDescriptor = getAssets().openFd("model.tflite");
        FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor());
        FileChannel fileChannel = inputStream.getChannel();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, fileDescriptor.getStartOffset(), fileDescriptor.getDeclaredLength());
    }

    // Classify the captured image using the TFLite model
    private String classifyImage(Bitmap bitmap) {
        ByteBuffer inputBuffer = ByteBuffer.allocateDirect(FLOAT_SIZE * IMAGE_SIZE * IMAGE_SIZE);
        inputBuffer.order(ByteOrder.nativeOrder());

        // Convert to grayscale & resize
        bitmap = Bitmap.createScaledBitmap(bitmap, IMAGE_SIZE, IMAGE_SIZE, true);
        int[] intValues = new int[IMAGE_SIZE * IMAGE_SIZE];
        bitmap.getPixels(intValues, 0, IMAGE_SIZE, 0, 0, IMAGE_SIZE, IMAGE_SIZE);

        for (int pixelValue : intValues) {
            int r = (pixelValue >> 16) & 0xFF;
            int g = (pixelValue >> 8) & 0xFF;
            int b = pixelValue & 0xFF;
            float grayscale = (r * 0.299f + g * 0.587f + b * 0.114f) / 255.0f; // Convert RGB to Grayscale
            inputBuffer.putFloat(grayscale);
        }

        // Run inference
        float[][] output = new float[1][NUM_CLASSES];
        if (tflite != null) {
            tflite.run(inputBuffer, output);
        } else {
            Toast.makeText(this, "Model is not initialized!", Toast.LENGTH_SHORT).show();
            return "Error";
        }

        // Get the predicted class
        int predictedClass = argMax(output[0]);

        // Map index to disease name
        String[] diseaseClasses = {"Black Rot", "Leaf Blight", "Esca", "Healthy"};
        return diseaseClasses[predictedClass];
    }

    // Find index of max probability in output array
    private int argMax(float[] array) {
        int maxIndex = 0;
        for (int i = 1; i < array.length; i++) {
            if (array[i] > array[maxIndex]) {
                maxIndex = i;
            }
        }
        return maxIndex;
    }
    private void showDropdownMenu(View v) {
        PopupMenu popupMenu = new PopupMenu(capture_image_activity.this, v);
        popupMenu.getMenuInflater().inflate(R.menu.dehaze_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.menu_home) {
                Intent intent = new Intent(capture_image_activity.this,MainActivity.class);
                startActivity(intent);
            } else if (itemId == R.id.menu_settings) {
                Intent intent = new Intent(capture_image_activity.this,SignUpActivity.class);
                startActivity(intent);
            } else if (itemId == R.id.menu_thanks) {
                Toast.makeText(capture_image_activity.this, "Thanks for Using an app", Toast.LENGTH_SHORT).show();
                return true;
            }
            return false;
        });

        popupMenu.show();
    }
}
