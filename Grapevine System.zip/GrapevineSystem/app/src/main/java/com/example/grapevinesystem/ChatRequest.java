package com.example.grapevinesystem;

public class ChatRequest {
    private String model = "gpt-3.5-turbo";
    private String prompt;

    public ChatRequest(String prompt) {
        this.prompt = prompt;
    }
}
