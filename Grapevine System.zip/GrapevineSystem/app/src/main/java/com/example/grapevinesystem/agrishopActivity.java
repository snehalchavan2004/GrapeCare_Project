package com.example.grapevinesystem;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class agrishopActivity extends AppCompatActivity {

    class AgriShop {
        String name;
        String location;

        AgriShop(String name, String location) {
            this.name = name;
            this.location = location;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agrishop);

        EditText locationInput = findViewById(R.id.locationInput);
        Button searchButton = findViewById(R.id.searchButton);
        TextView resultView = findViewById(R.id.resultView);

        List<AgriShop> agriShops = Arrays.asList(
                new AgriShop("Kisan Mart", "Karad"),
                new AgriShop("Bharat Agri Center", "Karad"),
                new AgriShop("Shivkrupa Agro Agency", "Karad"),
                new AgriShop("GreenAgro Shop", "Karad"),
                new AgriShop("Krishi Seva Kendra", "Karad"),
                new AgriShop("Farmers Supply", "Satara"),
                new AgriShop("Agri Needs", "Satara"),
                new AgriShop("Shivagiri Agro", "Satara"),
                new AgriShop("Sanjay Agro", "Satara"),
                new AgriShop("Kisan Krishi Center", "Satara"),
                new AgriShop("Nashik Agri Mart", "Nashik"),
                new AgriShop("Shiv Ganga Agro", "Nashik"),
                new AgriShop("Grape Growers Hub", "Nashik"),
                new AgriShop("Agri World Nashik", "Nashik"),
                new AgriShop("Maharashtra Agrotech", "Nashik"),
                new AgriShop("Sangli Agri Solutions", "Sangli"),
                new AgriShop("Shiv Ganga Agro Sangli", "Sangli"),
                new AgriShop("Farmers Mart Sangli", "Sangli"),
                new AgriShop("Krishi Mandir", "Sangli"),
                new AgriShop("Sangli Agro Market", "Sangli"),
                new AgriShop("Solapur Agri Mart", "Solapur"),
                new AgriShop("Shivaji Agro Supplies", "Solapur"),
                new AgriShop("Farmers Choice Solapur", "Solapur"),
                new AgriShop("Krishi Supply Solapur", "Solapur"),
                new AgriShop("Shree Agri Market Solapur", "Solapur"),
                new AgriShop("Pune Agri Center", "Pune"),
                new AgriShop("Shiv Shakti Agro", "Pune"),
                new AgriShop("Farmers Hub", "Pune"),
                new AgriShop("Krishi Vikash Kendra", "Pune"),
                new AgriShop("Agri Solutions Pune", "Pune"),
                new AgriShop("Aurangabad Agri Mart", "Aurangabad"),
                new AgriShop("Farmers Hub Aurangabad", "Aurangabad"),
                new AgriShop("Maharashtra Grape Mart", "Aurangabad"),
                new AgriShop("Agro Supplies Aurangabad", "Aurangabad"),
                new AgriShop("Shiv Agro Aurangabad", "Aurangabad"),
                new AgriShop("Kopargaon Agri Shop", "Kopargaon"),
                new AgriShop("Grape Growers Kopargaon", "Kopargaon"),
                new AgriShop("Krishi Supply Kopargaon", "Kopargaon"),
                new AgriShop("Agri Mart Kopargaon", "Kopargaon"),
                new AgriShop("Kopargaon Agri Center", "Kopargaon"),
                new AgriShop("Kolhapur Agro Mart", "Kolhapur"),
                new AgriShop("Krishi Kendra Kolhapur", "Kolhapur"),
                new AgriShop("Green Field Agro Kolhapur", "Kolhapur"),
                new AgriShop("Farmers Store Kolhapur", "Kolhapur"),
                new AgriShop("Maharashtra Agro Kolhapur", "Kolhapur"),
                new AgriShop("Beed Agro Center", "Beed"),
                new AgriShop("Farmers Hub Beed", "Beed"),
                new AgriShop("Krishi Market Latur", "Latur"),
                new AgriShop("Latur Agro Supplies", "Latur")
        );

        searchButton.setOnClickListener(v -> {
            String input = locationInput.getText().toString().trim();
            List<String> matchedShops = agriShops.stream()
                    .filter(shop -> shop.location.equalsIgnoreCase(input))
                    .map(shop -> shop.name)
                    .collect(Collectors.toList());

            resultView.setText(matchedShops.isEmpty() ? "No nearby shops found." : String.join("\n", matchedShops));
        });
    }
}