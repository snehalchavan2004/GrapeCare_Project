package com.example.grapevinesystem;

import androidx.appcompat.app.AppCompatActivity;

public class Product extends AppCompatActivity {
    private String name;
    private String imageUrl;

    public Product() {
        // Required for Firebase or other serialization frameworks
    }

    public Product(String name, String imageUrl) {
        this.name = name;
        this.imageUrl = imageUrl;
    }

    public String getName() {
        return name;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
