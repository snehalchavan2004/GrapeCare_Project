package com.example.grapevinesystem;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class feedback extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showFeedbackDialog(); // Directly show dialog when activity opens
    }

    private void showFeedbackDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("We value your feedback!");

        // Inflate custom layout for the dialog
        View view = getLayoutInflater().inflate(R.layout.activity_feedback, null);

        RatingBar ratingBar = view.findViewById(R.id.ratingBar);
        EditText feedbackInput = view.findViewById(R.id.feedbackInput);

        builder.setView(view);

        builder.setPositiveButton("Submit", (dialog, which) -> {
            float rating = ratingBar.getRating();
            String feedback = feedbackInput.getText().toString().trim();

            // Here you can save feedback or send to server
            Toast.makeText(this, "Thanks for your feedback!", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Cancel", null);

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
