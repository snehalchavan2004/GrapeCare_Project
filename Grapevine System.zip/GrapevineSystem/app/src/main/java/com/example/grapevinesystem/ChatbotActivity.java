package com.example.grapevinesystem;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ChatbotActivity extends AppCompatActivity {
    private RecyclerView recyclerViewChat;
    private ChatAdapter chatAdapter;
    private List<Message> messageList;
    private EditText editTextMessage;
    private Button btnSend;
    private TextToSpeech textToSpeech;
    private JSONArray diseasesArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatbot);

        recyclerViewChat = findViewById(R.id.recyclerViewChat);
        editTextMessage = findViewById(R.id.editTextMessage);
        btnSend = findViewById(R.id.btnSend);

        messageList = new ArrayList<>();
        chatAdapter = new ChatAdapter(messageList);
        recyclerViewChat.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewChat.setAdapter(chatAdapter);

        // Load JSON data
        diseasesArray = loadDiseasesFromJSON();


        // Handle Send Button Click
        btnSend.setOnClickListener(v -> processUserQuery(editTextMessage.getText().toString().trim()));
    }

    private JSONArray loadDiseasesFromJSON() {
        try (InputStream is = getAssets().open("diseasedata.json")) {
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            String json = new String(buffer, "UTF-8");
            android.util.Log.d("JSON_DEBUG", "JSON Content: " + json);
            JSONObject jsonObject = new JSONObject(json);
            return jsonObject.getJSONArray("diseasesArray");
        } catch (IOException | JSONException e) {
            e.printStackTrace();

            android.util.Log.e("JSON_ERROR", "Error loading JSON: " + e.getMessage());
            return null;
        }
    }

    private void processUserQuery(String query) {
        if (!query.isEmpty()) {
            messageList.add(new Message("You: " + query, true));
            chatAdapter.notifyDataSetChanged();

            // Get response from JSON
            String botResponse = getResponseFromJSON(query);
            messageList.add(new Message("Bot: " + botResponse, false));
            chatAdapter.notifyDataSetChanged();


        }
    }

    private String getResponseFromJSON(String query) {
        query = query.toLowerCase();

        // Handle greetings
        if (query.equals("hey") || query.equals("hi") || query.equals("hello")) {
            return "Hello! How can I assist you today?";
        }

        // Handle thank you responses
        if (query.contains("thank you") || query.contains("thanks")) {
            return "You're welcome! Let me know if you need any more help.";
        }

        // Debugging: Print if diseasesArray is NULL
        if (diseasesArray == null) {
            return "Error: JSON file not loaded. Please check assets folder.";
        }

        // Handle disease-related queries
        try {
            for (int i = 0; i < diseasesArray.length(); i++) {
                JSONObject disease = diseasesArray.getJSONObject(i);
                String name = disease.getString("name").toLowerCase();
                String symptoms = disease.getString("symptoms");
                String precautions = disease.getString("precautions");
                String info = disease.getString("Remedies");

                if (query.contains(name)) {
                    return "Disease: " + disease.getString("name") + "\nSymptoms: " + symptoms +
                            "\nPrecautions: " + precautions + "\nInfo: " + info;
                } else if (query.contains("symptoms of " + name)) {
                    return "Symptoms of " + disease.getString("name") + ": " + symptoms;
                } else if (query.contains("precautions for " + name)) {
                    return "Precautions for " + disease.getString("name") + ": " + precautions;
                } else if (query.contains("what is " + name)) {
                    return info;
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
            return "Error: Problem processing JSON data.";
        }

        return "I'm sorry, I don't have information on that. Try asking about grape diseases!";
    }

    @Override
    protected void onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }
}
