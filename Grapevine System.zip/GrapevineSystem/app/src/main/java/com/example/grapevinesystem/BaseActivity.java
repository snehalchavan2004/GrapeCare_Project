package com.example.grapevinesystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class BaseActivity extends AppCompatActivity {
    protected FloatingActionButton fabChatbot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inflate floating button layout
        View rootView = getLayoutInflater().inflate(R.layout.activity_base, null);
        setContentView(rootView);

        // Initialize floating chatbot button

    }
}
