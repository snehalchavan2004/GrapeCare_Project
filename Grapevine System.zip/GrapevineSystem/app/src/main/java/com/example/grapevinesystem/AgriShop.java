package com.example.grapevinesystem;

public class AgriShop {


        public String name;
        public String location;


        public AgriShop(String name, String location, int imageResId) {
            this.name = name;
            this.location = location;

        }
    }

