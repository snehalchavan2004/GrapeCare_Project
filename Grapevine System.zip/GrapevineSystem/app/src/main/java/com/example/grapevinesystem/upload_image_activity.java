package com.example.grapevinesystem;

import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.tensorflow.lite.Interpreter;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

public class upload_image_activity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private static final int IMAGE_SIZE = 128;  // Changed to match model input size
    private static final int FLOAT_SIZE = 4;
    private static final int NUM_CLASSES = 4;
    private ImageButton dehazeicon;
    private ImageView imageView, leftIcon;
    private TextView textView;
    private Button detectDisease;
    private Bitmap bitmap;
    private Interpreter tflite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_image);

        leftIcon = findViewById(R.id.lefticon);
        textView = findViewById(R.id.texttitle);

        detectDisease = findViewById(R.id.btnDetect);
        imageView = findViewById(R.id.capturedImageView);

        Button uploadButton = findViewById(R.id.uploadbutton);
        uploadButton.setOnClickListener(v -> openGallery());

        // Load default sample image
        bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.sample_leaf);
        imageView.setImageBitmap(bitmap);

        // Load TFLite model
        try {
            tflite = new Interpreter(loadModelFile());
            Log.d("UploadImageActivity", "Model loaded successfully.");
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading model!", Toast.LENGTH_SHORT).show();
        }

        // Back button
        leftIcon.setOnClickListener(view -> {
            Intent intent = new Intent(upload_image_activity.this, MainActivity.class);
            startActivity(intent);
        });

        // Set app title
        textView.setText("AgriXpert");

        // Detect Disease button
        detectDisease.setOnClickListener(v -> {
            if (bitmap != null) {
                String detectedDisease = classifyImage(bitmap);
                Intent intent = new Intent(upload_image_activity.this, result.class);
                intent.putExtra("disease_name", detectedDisease);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Please upload an image first!", Toast.LENGTH_SHORT).show();
            }
        });
        dehazeicon = findViewById(R.id.dehaze_icon);

        dehazeicon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("MainActivity", "Dehaze Icon Clicked!");
                showDropdownMenu(v);
            }
        });
    }

    // Open gallery to pick an image
    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            if (imageUri != null) {
                try {
                    // Convert URI to Bitmap and resize it
                    bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
                    bitmap = Bitmap.createScaledBitmap(bitmap, IMAGE_SIZE, IMAGE_SIZE, true);

                    // Display the selected image
                    imageView.setImageBitmap(bitmap);
                    Toast.makeText(this, "Image Selected Successfully!", Toast.LENGTH_SHORT).show();

                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Failed to load image!", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    // Load the TFLite model from assets folder
    private MappedByteBuffer loadModelFile() throws IOException {
        AssetFileDescriptor fileDescriptor = getAssets().openFd("model.tflite");
        FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor());
        FileChannel fileChannel = inputStream.getChannel();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, fileDescriptor.getStartOffset(), fileDescriptor.getDeclaredLength());
    }

    // Classify the uploaded image using the TFLite model
    private String classifyImage(Bitmap bitmap) {
        Log.d("UploadImageActivity", "Classifying Image...");
        if (tflite == null) {
            Log.e("TFLite", "Interpreter is null. Model not loaded.");
            return "Error: Model not loaded!";
        }

        // Convert RGB to Grayscale & Resize
        bitmap = Bitmap.createScaledBitmap(bitmap, IMAGE_SIZE, IMAGE_SIZE, true);
        ByteBuffer inputBuffer = ByteBuffer.allocateDirect(FLOAT_SIZE * IMAGE_SIZE * IMAGE_SIZE);
        inputBuffer.order(ByteOrder.nativeOrder());

        int[] intValues = new int[IMAGE_SIZE * IMAGE_SIZE];
        bitmap.getPixels(intValues, 0, IMAGE_SIZE, 0, 0, IMAGE_SIZE, IMAGE_SIZE);

        for (int pixelValue : intValues) {
            int r = (pixelValue >> 16) & 0xFF;
            int g = (pixelValue >> 8) & 0xFF;
            int b = pixelValue & 0xFF;
            float grayscale = (r * 0.299f + g * 0.587f + b * 0.114f) / 255.0f;  // Convert to grayscale
            inputBuffer.putFloat(grayscale);
        }

        // Run inference
        float[][] output = new float[1][NUM_CLASSES];
        tflite.run(inputBuffer, output);

        // Get the predicted class
        int predictedClass = argMax(output[0]);

        // Map index to disease name
        String[] diseaseClasses = {"Black Rot", "Leaf Blight", "Esca", "Healthy"};
        return diseaseClasses[predictedClass];
    }

    // Find index of max probability in output array
    private int argMax(float[] array) {
        int maxIndex = 0;
        for (int i = 1; i < array.length; i++) {
            if (array[i] > array[maxIndex]) {
                maxIndex = i;
            }
        }
        return maxIndex;
    }
    private void showDropdownMenu(View v) {
        PopupMenu popupMenu = new PopupMenu(upload_image_activity.this, v);
        popupMenu.getMenuInflater().inflate(R.menu.dehaze_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.menu_home) {
                Intent intent = new Intent(upload_image_activity.this,MainActivity.class);
                startActivity(intent);
                return true;
            } else if (itemId == R.id.menu_settings) {
                Intent intent = new Intent(upload_image_activity.this, SignUpActivity.class);
                startActivity(intent);
                return true;
            } else if (itemId == R.id.menu_thanks) {
                Toast.makeText(upload_image_activity.this, "Thanks For Using an app", Toast.LENGTH_SHORT).show();
                return true;
            }
            return false;
        });

        popupMenu.show();
    }
}
