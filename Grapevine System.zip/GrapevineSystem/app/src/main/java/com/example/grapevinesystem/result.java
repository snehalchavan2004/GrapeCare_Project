package com.example.grapevinesystem;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class result extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ProductAdapter adapter;
    private List<Product> productList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // Apply window insets (optional UI adjustment)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Get detected disease from intent
        String disease = getIntent().getStringExtra("disease_name");

        // Initialize TextViews
        TextView txtDisease = findViewById(R.id.txtDisease);
        TextView txtRemedy = findViewById(R.id.txtRemedy);
        TextView txtQuality = findViewById(R.id.txtQuality);


        txtDisease.setText("Detected Disease: " + disease);
        txtRemedy.setText("Recommended Remedy: " + getRemedy(disease));
        txtQuality.setText("Export/Import Quality: " + getQualityRating(disease));
        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)); // Horizontal Layout

        // Create Product List

        productList = getRecommendedProducts(disease);
        // Set up adapter
        adapter = new ProductAdapter(this,productList);
        recyclerView.setAdapter(adapter);
    }

    public List<Product> getRecommendedProducts(String disease) {
        List<Product> products = new ArrayList<>();

        switch (disease) {
            case "Black Rot":
                products.add(new Product("Fungicide Spray","https://5.imimg.com/data5/SELLER/Default/2023/12/368830884/EQ/RP/AX/44479274/arigato-500x500.png"));
                products.add(new Product("Leaf Treatment Kit", "https://m.media-amazon.com/images/I/61KitdBVZmL._AC_UF1000,1000_QL80_.jpg"));
                break;

            case "Leaf Blight":
                products.add(new Product("Organic Pesticide", "https://5.imimg.com/data5/SELLER/Default/2021/6/WP/AZ/NY/22627755/organic-pesticide-500x500.jpg"));
                products.add(new Product("Blight Prevention Spray", "https://i.ebayimg.com/images/g/-jcAAOSw6oFi1lo9/s-l1200.jpg"));
                break;

            case "Esca":
                products.add(new Product("Biofungicide Pack", "https://cdn.shopify.com/s/files/1/0722/2059/files/ebs-bacillus-subtilis-bio-fungicide-file-16961.png?v=1737479291"));
                products.add(new Product("Soil Nutrient Booster", "https://5.imimg.com/data5/SELLER/Default/2023/7/323259344/JY/QK/NJ/15279188/soil-booster-fertilizer.jpeg"));
                break;

            case "Healthy":
                products.add(new Product("Growth Enhancer", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDwC1oxqObcsYRi739-Wn3tgGid2l_tvQrSg&s"));
                products.add(new Product("Organic Fertilizer", "https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRuk3-WOPp6T9F7A5MzKG8d0zEv_VNFTBhuptmt6myW_NZAc_CmzM-6IEnEoXE_YF8iV4Q4XHD-ukL6aQ6zN19XH-LEf6Jqq7S6Sz_QzWZySUvgboIJUBsp&usqp=CAE"));
                break;

            default:
                products.add(new Product("General Crop Care Kit", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5R4rDIOfwzdE5Re-sFssBB_FVf6e_TshPxA&s"));
                break;
        }
        return products;
    }
    // Method to return remedies based on detected disease
    public String getRemedy(String disease) {
        switch (disease) {
            case "Black Rot":
                return "\n• Sanitation is crucial for controlling black rot.\n" +
                        "• Regularly check and prune infected leaves in spring.\n" +
                        "• Remove any mummified berries from the ground to prevent airborne infection.\n" +
                        "• Use preventive fungicide sprays from early bloom to 3-4 weeks after initial bloom.";

            case "Leaf Blight":
                return " • Apply sulfur-based sprays to control fungal growth.\n" +
                        "• Improve air circulation around the plants to reduce moisture buildup.\n" +
                        "• Preventive fungicides should be applied before disease onset.\n" +
                        "• Reduces long-term disease impact and minimizes costly post-infection treatments.";

            case "Esca":
                return " • Destroy infected vines to prevent disease spread.\n" +
                        "• Apply biofungicides as a preventive measure.\n" +
                        "• Use targeted fungicide and bactericide treatments.\n" +
                        "• Consult local agricultural experts for the best treatment options.";

            case "Healthy":
                return " • No treatment needed.\n" +
                        "• Maintain good vineyard hygiene to prevent diseases.\n" +
                        "• Regularly inspect plants for early signs of infection.";

            default:
                return "• Consult an agricultural expert for precise diagnosis and treatment.";
        }
    }
    public String getQualityRating(String disease) {
        switch (disease) {
            case "Black Rot":
                return "Poor (Export after cure only)";
            case "Leaf Blight":
                return "Export after Recovery";
            case "Esca":
                return "Export after removing infected Vines";
            case "Healthy":
                return "Excellent (Ideal for export)";
            default:
                return "Unknown";
        }
    }



}
